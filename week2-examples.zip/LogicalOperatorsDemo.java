// Demonstrate the relational and logical operators.
class LogicalOperatorsDemo
{
  public static void main(String[] args)
  {
    boolean b1, b2;
    // logical operators (boolean logic)
    b1 = true;
    b2 = false;
    if(b1 & b2) System.out.println("this won't execute");
    if(!(b1 & b2)) System.out.println("!(b1 & b2) is true");
    if(b1 | b2) System.out.println("b1 | b2 is true");
    if(b1 ^ b2) System.out.println("b1 ^ b2 is true");
  }
}