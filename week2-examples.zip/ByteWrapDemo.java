class ByteWrapDemo
{
  public static void main(String[] args)
  {
      byte myByte;
      int counter;
      myByte = (byte)128;
      System.out.println(myByte);
      for(myByte = 0, counter = 0; counter < 260; myByte++, counter++)
      {
          System.out.println("counter: " + counter + " casted byte: " + (byte)myByte);
      }
  }
}