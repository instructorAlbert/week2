/* Demonstrate byte value when cast from int */
class CastDemoAsLoop
{
  public static void main(String[] args)
  {
    byte b;
    int i;
    for(i = 0; i < 258; i++)
    {
        if (i == 127)
        {
            System.out.println("The constant value of Byte.MAX_VALUE is " + Byte.MAX_VALUE);
        }
        b = (byte) i;
        System.out.println("Value of b: " + b);
    }
  }
}