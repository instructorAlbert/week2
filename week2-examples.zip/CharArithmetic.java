class CharArithmetic
{
    public static void main(String[] args)
    {
        for(int counter = 'a'; counter <= 'z'; counter++)
        {
            System.out.println(counter);
        }
        for(int counter = 'a'; counter <= 'z'; counter++)
        {
            System.out.println((char)counter);
        }
    }
}