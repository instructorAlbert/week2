// Demonstrate the relational and logical operators.
class CombiningOperatorsDemo
{
  public static void main(String[] args)
  {
    if((2 + 2 ==4) & ("hello".length() >= 5)) System.out.println("true and true");
    if((2 + 2 ==4) || ("hello".length() >= 50)) System.out.println("true or true");
  }
}