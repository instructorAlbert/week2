import java.util.*;
 
class Utility
{
    int counter = 0;
    int runningTotal = 1;
 
    void printAValue(int lowNumber, int highNumber)
    {
        if((lowNumber < 1) | (highNumber >= 20))
        {
            System.out.println("Illegal range");
        }
        else
        {
            System.out.println("highNumber is " + highNumber + " and lowNumber is " + lowNumber);
            System.out.println("We will run the loop " + (highNumber - lowNumber) + " times.");
            for(counter = highNumber - lowNumber; counter >= 0; counter--)
            {
                if(counter > 10)
                {
                    System.out.println("counter is " + counter);
                }
                else if(counter <= 10 & counter > 5)
                {
                    System.out.println("counter is between 10 and 6: " + counter);
                }
                else
                {
                    System.out.println("counter is now 5 or less : " + counter);
                }
            }
        }
    }
}
class RangeTestDemo
{
    public static void main(String[] args)
    {
        Utility myUtility = new Utility();
        Scanner myScanner = new Scanner(System.in);
        System.out.println("Type in a positive value to be the low value of the range.");
        int startNumber = myScanner.nextInt();
        System.out.println("Type in a higher value, but less than 20, to be the upper limit of the range.");
        int endNumber = myScanner.nextInt();
        myUtility.printAValue(startNumber, endNumber);
        System.out.println("Goodbye");
    }
}