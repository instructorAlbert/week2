class MaxValueDemo
{
    public static void main(String[] args)
    {
        System.out.println("The maximum value of an integer is " + Integer.MAX_VALUE);
        System.out.println("If we add 1 to that value, we get " + (Integer.MAX_VALUE + 1));
        System.out.println("The maximum value of a long is " + Long.MAX_VALUE);
    }
}