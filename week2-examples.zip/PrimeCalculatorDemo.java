/* Instantiate an object with a method */
class PrimeCalculator
{
    void showPrimes()
    {
        // declare local variables
        int i, j;
        boolean isPrime;
        for(i=1; i< 20; i++)
        {
            isPrime = true;
            // see if the number is evenly divisible
            for(j=2; j <= i/j; j++)
            {
                // if it is, then its not prime
                if((i%j) == 0)
                {
                    isPrime = false;
                }
            } // end of inner for
            if(isPrime)
            {
                System.out.println(i + " is prime.");
            }
        } // end of outer for
    } // end of method
} // end of class
class PrimeCalculatorDemo
{
    public static void main(String[] args)
    {
        PrimeCalculator pc = new PrimeCalculator();
        pc.showPrimes();
    } // end of main
} // end of class