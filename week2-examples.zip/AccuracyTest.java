class AccuracyTest
{
    public static void main(String[] args)
    {
        double resultValuePointThree = 0.1 + 0.1 + 0.1;
        double resultValuePointSix = resultValuePointThree + resultValuePointThree;
        System.out.println(resultValuePointThree);
        // 0.30000000000000004
        System.out.println(resultValuePointSix);
        // 0.6000000000000001
    }
}