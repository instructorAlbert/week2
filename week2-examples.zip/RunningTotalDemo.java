// Demonstrate the compound operator +=
class RunningTotalDemo
{
    public static void main(String[] args)
    {
        double broccoliPrice = 1.29;
        double runningTotal = 0;
        System.out.println("Each pound of broccoli costs $1.29. Let's assume you want to buy 5 pounds.");
        for(int i = 1; i <= 5; i++)
        {
            System.out.println("This pound of broccoli costs " + broccoliPrice);
            System.out.println(" and the running total is " + (runningTotal += broccoliPrice) + " and you now have " + i + " pounds of broccoli.");
        }
    }
}